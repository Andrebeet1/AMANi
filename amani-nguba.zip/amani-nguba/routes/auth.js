/**
 * Routes d'authentification
 */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const { query } = require('../config/db');

/**
 * GET /login - Page de connexion
 */
router.get('/login', (req, res) => {
  if (req.session.user) {
    return res.redirect('/dashboard');
  }
  res.render('auth/login', {
    title: 'Connexion',
    layout: false
  });
});

/**
 * POST /login - Traitement de la connexion
 */
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      req.flash('error', 'Email et mot de passe requis');
      return res.redirect('/auth/login');
    }

    const result = await query(
      'SELECT * FROM users WHERE email = $1 AND actif = true',
      [email.toLowerCase()]
    );

    if (result.rows.length === 0) {
      req.flash('error', 'Identifiants invalides');
      return res.redirect('/auth/login');
    }

    const user = result.rows[0];
    const validPassword = await bcrypt.compare(password, user.password_hash);

    if (!validPassword) {
      req.flash('error', 'Identifiants invalides');
      return res.redirect('/auth/login');
    }

    // Mise à jour de la dernière connexion
    await query(
      'UPDATE users SET derniere_connexion = CURRENT_TIMESTAMP WHERE id = $1',
      [user.id]
    );

    // Création de la session
    req.session.user = {
      id: user.id,
      uuid: user.uuid,
      nom: user.nom,
      postnom: user.postnom,
      prenom: user.prenom,
      email: user.email,
      role: user.role,
      paroisse_id: user.paroisse_id
    };

    req.flash('success', `Bienvenue, ${user.prenom || user.nom} !`);
    res.redirect('/dashboard');
  } catch (err) {
    console.error('Erreur login:', err);
    req.flash('error', 'Erreur lors de la connexion');
    res.redirect('/auth/login');
  }
});

/**
 * GET /register - Page d'inscription (pasteur/tresorier uniquement par super_admin)
 */
router.get('/register', (req, res) => {
  res.render('auth/register', {
    title: 'Inscription',
    layout: false
  });
});

/**
 * POST /register - Inscription
 */
router.post('/register', async (req, res) => {
  try {
    const { nom, postnom, prenom, email, password, confirm_password, role, paroisse_id, telephone, sexe } = req.body;

    // Validation
    if (!nom || !email || !password || !role) {
      req.flash('error', 'Tous les champs obligatoires doivent être remplis');
      return res.redirect('/auth/register');
    }

    if (password !== confirm_password) {
      req.flash('error', 'Les mots de passe ne correspondent pas');
      return res.redirect('/auth/register');
    }

    if (password.length < 8) {
      req.flash('error', 'Le mot de passe doit contenir au moins 8 caractères');
      return res.redirect('/auth/register');
    }

    // Vérifier si l'email existe déjà
    const existing = await query('SELECT id FROM users WHERE email = $1', [email.toLowerCase()]);
    if (existing.rows.length > 0) {
      req.flash('error', 'Cet email est déjà utilisé');
      return res.redirect('/auth/register');
    }

    // Hash du mot de passe
    const passwordHash = await bcrypt.hash(password, 10);

    // Insertion
    const result = await query(
      `INSERT INTO users (nom, postnom, prenom, email, password_hash, role, paroisse_id, telephone, sexe, date_adhesion)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, CURRENT_DATE)
       RETURNING id, email, role`,
      [nom, postnom || null, prenom || null, email.toLowerCase(), passwordHash, role, paroisse_id || null, telephone || null, sexe || null]
    );

    console.log('✅ Nouvel utilisateur créé:', result.rows[0].email);
    req.flash('success', 'Compte créé avec succès ! Vous pouvez vous connecter.');
    res.redirect('/auth/login');
  } catch (err) {
    console.error('Erreur inscription:', err);
    req.flash('error', 'Erreur lors de la création du compte');
    res.redirect('/auth/register');
  }
});

/**
 * GET /logout - Déconnexion
 */
router.get('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      console.error('Erreur logout:', err);
    }
    res.redirect('/auth/login');
  });
});

/**
 * GET /profile - Profil utilisateur
 */
router.get('/profile', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/auth/login');
  }
  try {
    const result = await query(
      `SELECT u.*, p.nom as paroisse_nom, p.niveau as paroisse_niveau
       FROM users u
       LEFT JOIN paroisses p ON u.paroisse_id = p.id
       WHERE u.id = $1`,
      [req.session.user.id]
    );
    res.render('auth/profile', {
      title: 'Mon profil',
      profile: result.rows[0]
    });
  } catch (err) {
    console.error('Erreur profil:', err);
    req.flash('error', 'Erreur lors du chargement du profil');
    res.redirect('/dashboard');
  }
});

/**
 * POST /profile - Mise à jour du profil
 */
router.post('/profile', async (req, res) => {
  if (!req.session.user) {
    return res.redirect('/auth/login');
  }
  try {
    const { telephone, adresse, current_password, new_password } = req.body;
    const userId = req.session.user.id;

    if (new_password) {
      // Vérifier l'ancien mot de passe
      const userRes = await query('SELECT password_hash FROM users WHERE id = $1', [userId]);
      const valid = await bcrypt.compare(current_password, userRes.rows[0].password_hash);
      if (!valid) {
        req.flash('error', 'Mot de passe actuel incorrect');
        return res.redirect('/auth/profile');
      }
      const newHash = await bcrypt.hash(new_password, 10);
      await query(
        'UPDATE users SET telephone = $1, adresse = $2, password_hash = $3 WHERE id = $4',
        [telephone, adresse, newHash, userId]
      );
    } else {
      await query(
        'UPDATE users SET telephone = $1, adresse = $2 WHERE id = $3',
        [telephone, adresse, userId]
      );
    }

    req.flash('success', 'Profil mis à jour avec succès');
    res.redirect('/auth/profile');
  } catch (err) {
    console.error('Erreur mise à jour profil:', err);
    req.flash('error', 'Erreur lors de la mise à jour');
    res.redirect('/auth/profile');
  }
});

module.exports = router;
