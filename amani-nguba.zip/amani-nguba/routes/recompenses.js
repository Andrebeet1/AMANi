/**
 * Routes récompenses - Fidèles de l'année (Novembre)
 * Système de distinctions : meilleur du mois (fidélité + revenu)
 */

const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

/**
 * GET /recompenses - Page des récompenses
 */
router.get('/', async (req, res) => {
  try {
    const { annee } = req.query;
    const filterYear = annee || new Date().getFullYear();

    // Récompenses déjà attribuées
    const recompensesAttribuees = await query(`
      SELECT r.*, u.nom, u.postnom, u.prenom, p.nom as paroisse_nom, p.niveau
      FROM recompenses r
      LEFT JOIN users u ON r.user_id = u.id
      LEFT JOIN paroisses p ON r.paroisse_id = p.id
      WHERE r.annee = $1
      ORDER BY r.mois DESC, r.type_recompense
    `, [filterYear]);

    // Meilleurs de chaque mois (calculés en live)
    const meilleursParMois = await query(`
      WITH stats_mensuelles AS (
        SELECT
          u.id as user_id,
          u.nom, u.postnom, u.prenom,
          p.nom as paroisse_nom, p.niveau,
          EXTRACT(MONTH FROM t.date_transaction)::INTEGER as mois,
          COUNT(DISTINCT t.id) as nb_transactions,
          SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END) as total_entrees,
          SUM(CASE WHEN t.type = 'sortie' THEN t.montant ELSE 0 END) as total_sorties
        FROM transactions t
        JOIN users u ON t.user_id = u.id
        LEFT JOIN paroisses p ON u.paroisse_id = p.id
        WHERE t.statut = 'valide'
          AND EXTRACT(YEAR FROM t.date_transaction) = $1
        GROUP BY u.id, u.nom, u.postnom, u.prenom, p.nom, p.niveau, mois
      )
      SELECT *,
        (nb_transactions * 10 + total_entrees / 1000) as score_fidelite
      FROM stats_mensuelles
      ORDER BY mois, score_fidelite DESC
    `, [filterYear]);

    // Grouper par mois
    const parMois = {};
    meilleursParMois.rows.forEach(r => {
      if (!parMois[r.mois]) parMois[r.mois] = [];
      parMois[r.mois].push(r);
    });

    // Fidèles de l'année (cumul)
    const fidelesAnnee = await query(`
      SELECT
        u.id, u.nom, u.postnom, u.prenom, u.email, u.telephone,
        p.nom as paroisse_nom, p.niveau,
        COUNT(DISTINCT t.id) as nb_transactions,
        COUNT(DISTINCT EXTRACT(MONTH FROM t.date_transaction)) as mois_actifs,
        SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END) as total_contribution
      FROM users u
      LEFT JOIN transactions t ON t.user_id = u.id
        AND t.statut = 'valide'
        AND EXTRACT(YEAR FROM t.date_transaction) = $1
      LEFT JOIN paroisses p ON u.paroisse_id = p.id
      WHERE u.role NOT IN ('super_admin', 'pasteur')
      GROUP BY u.id, u.nom, u.postnom, u.prenom, u.email, u.telephone, p.nom, p.niveau
      HAVING COUNT(t.id) > 0
      ORDER BY total_contribution DESC, mois_actifs DESC
      LIMIT 20
    `, [filterYear]);

    // Top entités par mois
    const topEntitesParMois = await query(`
      SELECT
        p.id, p.nom, p.niveau,
        EXTRACT(MONTH FROM t.date_transaction)::INTEGER as mois,
        SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END) as entrees
      FROM paroisses p
      JOIN transactions t ON t.paroisse_id = p.id
      WHERE t.statut = 'valide'
        AND EXTRACT(YEAR FROM t.date_transaction) = $1
      GROUP BY p.id, p.nom, p.niveau, mois
      ORDER BY mois, entrees DESC
    `, [filterYear]);

    res.render('recompenses/index', {
      title: `Récompenses ${filterYear}`,
      recompensesAttribuees: recompensesAttribuees.rows,
      parMois,
      fidelesAnnee: fidelesAnnee.rows,
      topEntitesParMois: topEntitesParMois.rows,
      annee: parseInt(filterYear)
    });
  } catch (err) {
    console.error('Erreur récompenses:', err);
    req.flash('error', 'Erreur lors du chargement');
    res.redirect('/dashboard');
  }
});

/**
 * POST /recompenses/attribuer - Attribuer une récompense
 */
router.post('/attribuer', async (req, res) => {
  try {
    const { user_id, paroisse_id, type_recompense, annee, mois, score, recompense, motif } = req.body;

    if (!type_recompense || !annee || !mois) {
      req.flash('error', 'Données manquantes');
      return res.redirect('/recompenses');
    }

    await query(
      `INSERT INTO recompenses (user_id, paroisse_id, type_recompense, annee, mois, score, recompense, motif)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
      [user_id || null, paroisse_id || null, type_recompense, annee, mois, score || null, recompense || null, motif || null]
    );

    req.flash('success', 'Récompense attribuée avec succès');
    res.redirect(`/recompenses?annee=${annee}`);
  } catch (err) {
    console.error('Erreur attribution récompense:', err);
    req.flash('error', 'Erreur lors de l\'attribution');
    res.redirect('/recompenses');
  }
});

/**
 * GET /recompenses/calendrier - Vue calendrier des cérémonies
 */
router.get('/calendrier', async (req, res) => {
  try {
    const evenements = await query(`
      SELECT a.*, p.nom as paroisse_nom
      FROM annonces a
      LEFT JOIN paroisses p ON a.paroisse_id = p.id
      WHERE a.publie = true
        AND (
          a.type IN ('activite', 'culte', 'general')
          AND EXTRACT(MONTH FROM a.date_publication) = 11
        )
      ORDER BY a.date_publication
    `);

    res.render('recompenses/calendrier', {
      title: 'Calendrier des récompenses',
      evenements: evenements.rows
    });
  } catch (err) {
    console.error('Erreur calendrier:', err);
    req.flash('error', 'Erreur');
    res.redirect('/recompenses');
  }
});

module.exports = router;
