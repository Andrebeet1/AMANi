/**
 * Routes dashboard
 */

const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

/**
 * GET /dashboard - Tableau de bord principal
 */
router.get('/', async (req, res) => {
  try {
    const userId = req.session.user.id;
    const userRole = req.session.user.role;

    // Statistiques globales
    const stats = await query(`
      SELECT
        COALESCE(SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END), 0) as total_entrees,
        COALESCE(SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END), 0) as total_sorties,
        COUNT(*) as total_transactions
      FROM transactions
      WHERE statut = 'valide'
        AND EXTRACT(MONTH FROM date_transaction) = EXTRACT(MONTH FROM CURRENT_DATE)
        AND EXTRACT(YEAR FROM date_transaction) = EXTRACT(YEAR FROM CURRENT_DATE)
    `);

    // Statistiques de l'année
    const statsAnnee = await query(`
      SELECT
        COALESCE(SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END), 0) as entrees_annee,
        COALESCE(SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END), 0) as sorties_annee
      FROM transactions
      WHERE statut = 'valide'
        AND EXTRACT(YEAR FROM date_transaction) = EXTRACT(YEAR FROM CURRENT_DATE)
    `);

    // Évolution mensuelle
    const evolution = await query(`
      SELECT
        EXTRACT(MONTH FROM date_transaction)::INTEGER as mois,
        SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END) as entrees,
        SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END) as sorties
      FROM transactions
      WHERE statut = 'valide'
        AND EXTRACT(YEAR FROM date_transaction) = EXTRACT(YEAR FROM CURRENT_DATE)
      GROUP BY mois
      ORDER BY mois
    `);

    // Top catégories d'entrées
    const topCategories = await query(`
      SELECT c.nom, SUM(t.montant) as total
      FROM transactions t
      JOIN categories_transactions c ON t.categorie_id = c.id
      WHERE t.type = 'entree' AND t.statut = 'valide'
        AND EXTRACT(YEAR FROM t.date_transaction) = EXTRACT(YEAR FROM CURRENT_DATE)
      GROUP BY c.nom
      ORDER BY total DESC
      LIMIT 5
    `);

    // Dernières transactions
    const dernieresTransactions = await query(`
      SELECT t.*, c.nom as categorie_nom, p.nom as paroisse_nom
      FROM transactions t
      LEFT JOIN categories_transactions c ON t.categorie_id = c.id
      LEFT JOIN paroisses p ON t.paroisse_id = p.id
      WHERE t.statut = 'valide'
      ORDER BY t.created_at DESC
      LIMIT 10
    `);

    // Annonces récentes
    const annonces = await query(`
      SELECT id, titre, type, date_publication, urgent
      FROM annonces
      WHERE publie = true
        AND (date_expiration IS NULL OR date_expiration >= CURRENT_DATE)
      ORDER BY urgent DESC, date_publication DESC
      LIMIT 5
    `);

    // Soldes par niveau
    const soldesParNiveau = await query(`
      SELECT niveau,
        COUNT(*) as nb_entites,
        COALESCE(SUM(solde), 0) as solde_total
      FROM v_soldes_paroisses
      GROUP BY niveau
      ORDER BY CASE niveau
        WHEN 'paroisse' THEN 1
        WHEN 'branche' THEN 2
        WHEN 'brachet' THEN 3
        WHEN 'chapelle' THEN 4
        WHEN 'cellule' THEN 5
      END
    `);

    // Statistiques paroisses
    const paroisseStats = await query(`
      SELECT
        (SELECT COUNT(*) FROM paroisses WHERE actif = true) as total_paroisses,
        (SELECT COUNT(*) FROM users WHERE actif = true) as total_users,
        (SELECT COUNT(*) FROM users WHERE actif = true AND role LIKE 'tresorier%') as total_tresoriers
    `);

    res.render('dashboard/index', {
      title: 'Tableau de bord',
      stats: stats.rows[0],
      statsAnnee: statsAnnee.rows[0],
      evolution: evolution.rows,
      topCategories: topCategories.rows,
      dernieresTransactions: dernieresTransactions.rows,
      annonces: annonces.rows,
      soldesParNiveau: soldesParNiveau.rows,
      paroisseStats: paroisseStats.rows[0]
    });
  } catch (err) {
    console.error('Erreur dashboard:', err);
    req.flash('error', 'Erreur lors du chargement du tableau de bord');
    res.render('dashboard/index', {
      title: 'Tableau de bord',
      stats: { total_entrees: 0, total_sorties: 0, total_transactions: 0 },
      statsAnnee: { entrees_annee: 0, sorties_annee: 0 },
      evolution: [],
      topCategories: [],
      dernieresTransactions: [],
      annonces: [],
      soldesParNiveau: [],
      paroisseStats: { total_paroisses: 0, total_users: 0, total_tresoriers: 0 }
    });
  }
});

/**
 * GET /dashboard/api/stats - API JSON pour AJAX
 */
router.get('/api/stats', async (req, res) => {
  try {
    const { annee, paroisse_id } = req.query;
    const filterYear = annee || new Date().getFullYear();

    let sql = `
      SELECT
        EXTRACT(MONTH FROM date_transaction)::INTEGER as mois,
        SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END) as entrees,
        SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END) as sorties
      FROM transactions
      WHERE statut = 'valide'
        AND EXTRACT(YEAR FROM date_transaction) = $1
    `;
    const params = [filterYear];
    if (paroisse_id) { params.push(paroisse_id); sql += ` AND paroisse_id = $${params.length}`; }
    sql += ' GROUP BY mois ORDER BY mois';

    const evolution = await query(sql, params);
    res.json(evolution.rows);
  } catch (err) {
    console.error('Erreur API stats:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
