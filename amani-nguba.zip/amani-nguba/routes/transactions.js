/**
 * Routes transactions - Entrées et sorties
 */

const express = require('express');
const router = express.Router();
const { query } = require('../config/db');
const PDFDocument = require('pdfkit');
const XLSX = require('xlsx');

/**
 * GET /transactions - Liste des transactions
 */
router.get('/', async (req, res) => {
  try {
    const { paroisse_id, type, categorie_id, date_debut, date_fin, search } = req.query;
    let sql = `
      SELECT t.*, c.nom as categorie_nom, p.nom as paroisse_nom, p.niveau,
             u.nom as user_nom, u.postnom as user_postnom, u.prenom as user_prenom
      FROM transactions t
      LEFT JOIN categories_transactions c ON t.categorie_id = c.id
      LEFT JOIN paroisses p ON t.paroisse_id = p.id
      LEFT JOIN users u ON t.user_id = u.id
      WHERE 1=1
    `;
    const params = [];
    if (paroisse_id) {
      params.push(paroisse_id);
      sql += ` AND t.paroisse_id = $${params.length}`;
    }
    if (type) {
      params.push(type);
      sql += ` AND t.type = $${params.length}`;
    }
    if (categorie_id) {
      params.push(categorie_id);
      sql += ` AND t.categorie_id = $${params.length}`;
    }
    if (date_debut) {
      params.push(date_debut);
      sql += ` AND t.date_transaction >= $${params.length}`;
    }
    if (date_fin) {
      params.push(date_fin);
      sql += ` AND t.date_transaction <= $${params.length}`;
    }
    if (search) {
      params.push(`%${search}%`);
      sql += ` AND (t.description ILIKE $${params.length} OR t.reference ILIKE $${params.length})`;
    }
    sql += ' ORDER BY t.date_transaction DESC, t.created_at DESC LIMIT 200';

    const transactions = await query(sql, params);

    const paroisses = await query('SELECT id, nom, niveau FROM paroisses WHERE actif = true ORDER BY niveau, nom');
    const categories = await query('SELECT id, nom, type FROM categories_transactions ORDER BY type, nom');

    res.render('transactions/index', {
      title: 'Transactions',
      transactions: transactions.rows,
      paroisses: paroisses.rows,
      categories: categories.rows,
      filtres: req.query
    });
  } catch (err) {
    console.error('Erreur transactions:', err);
    req.flash('error', 'Erreur lors du chargement');
    res.redirect('/dashboard');
  }
});

/**
 * GET /transactions/new - Formulaire de création
 */
router.get('/new', async (req, res) => {
  try {
    const paroisses = await query('SELECT id, nom, niveau FROM paroisses WHERE actif = true ORDER BY niveau, nom');
    const categories = await query('SELECT id, nom, type FROM categories_transactions ORDER BY type, nom');

    res.render('transactions/form', {
      title: 'Nouvelle transaction',
      transaction: null,
      paroisses: paroisses.rows,
      categories: categories.rows,
      action: '/transactions'
    });
  } catch (err) {
    console.error('Erreur form transaction:', err);
    req.flash('error', 'Erreur');
    res.redirect('/transactions');
  }
});

/**
 * POST /transactions - Créer une transaction
 */
router.post('/', async (req, res) => {
  try {
    const {
      paroisse_id, categorie_id, type, montant, devise,
      description, date_transaction, mode_paiement, reference
    } = req.body;

    if (!paroisse_id || !categorie_id || !type || !montant || !date_transaction) {
      req.flash('error', 'Tous les champs obligatoires doivent être remplis');
      return res.redirect('/transactions/new');
    }

    const result = await query(
      `INSERT INTO transactions
       (paroisse_id, categorie_id, user_id, type, montant, devise, description, date_transaction, mode_paiement, reference, statut)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, 'valide')
       RETURNING id`,
      [
        paroisse_id, categorie_id, req.session.user.id, type, montant,
        devise || 'CDF', description || null, date_transaction,
        mode_paiement || 'especes', reference || null
      ]
    );

    req.flash('success', `Transaction enregistrée avec succès (${type === 'entree' ? '+' : '-'}${montant} ${devise || 'CDF'})`);
    res.redirect('/transactions');
  } catch (err) {
    console.error('Erreur création transaction:', err);
    req.flash('error', 'Erreur lors de la création');
    res.redirect('/transactions/new');
  }
});

/**
 * GET /transactions/:id - Détail
 */
router.get('/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const result = await query(`
      SELECT t.*, c.nom as categorie_nom, p.nom as paroisse_nom, p.niveau as paroisse_niveau,
             u.nom as user_nom, u.postnom as user_postnom, u.prenom as user_prenom
      FROM transactions t
      LEFT JOIN categories_transactions c ON t.categorie_id = c.id
      LEFT JOIN paroisses p ON t.paroisse_id = p.id
      LEFT JOIN users u ON t.user_id = u.id
      WHERE t.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      req.flash('error', 'Transaction non trouvée');
      return res.redirect('/transactions');
    }

    res.render('transactions/detail', {
      title: 'Détail transaction',
      transaction: result.rows[0]
    });
  } catch (err) {
    console.error('Erreur détail transaction:', err);
    req.flash('error', 'Erreur');
    res.redirect('/transactions');
  }
});

/**
 * POST /transactions/:id/delete - Annuler
 */
router.post('/:id/delete', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await query(
      `UPDATE transactions SET statut = 'annule' WHERE id = $1`,
      [id]
    );
    req.flash('success', 'Transaction annulée');
    res.redirect('/transactions');
  } catch (err) {
    console.error('Erreur annulation:', err);
    req.flash('error', 'Erreur');
    res.redirect('/transactions');
  }
});

/**
 * GET /transactions/export/pdf - Export PDF
 */
router.get('/export/pdf', async (req, res) => {
  try {
    const { paroisse_id, type, date_debut, date_fin } = req.query;
    let sql = `
      SELECT t.date_transaction, t.type, t.montant, t.devise, t.description,
             c.nom as categorie, p.nom as paroisse
      FROM transactions t
      LEFT JOIN categories_transactions c ON t.categorie_id = c.id
      LEFT JOIN paroisses p ON t.paroisse_id = p.id
      WHERE t.statut = 'valide'
    `;
    const params = [];
    if (paroisse_id) { params.push(paroisse_id); sql += ` AND t.paroisse_id = $${params.length}`; }
    if (type) { params.push(type); sql += ` AND t.type = $${params.length}`; }
    if (date_debut) { params.push(date_debut); sql += ` AND t.date_transaction >= $${params.length}`; }
    if (date_fin) { params.push(date_fin); sql += ` AND t.date_transaction <= $${params.length}`; }
    sql += ' ORDER BY t.date_transaction DESC';

    const result = await query(sql, params);

    // Création du PDF
    const doc = new PDFDocument({ margin: 50, size: 'A4', layout: 'landscape' });
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="transactions-${Date.now()}.pdf"`);
    doc.pipe(res);

    // En-tête
    doc.fontSize(18).text('AMANI NGUBA - Rapport des Transactions', { align: 'center' });
    doc.moveDown(0.3);
    doc.fontSize(10).text(`Date d'édition: ${new Date().toLocaleDateString('fr-FR')}`, { align: 'center' });
    doc.moveDown(1);

    // Tableau
    const tableTop = 120;
    const colWidths = { date: 80, type: 50, paroisse: 130, categorie: 100, desc: 200, montant: 90 };
    let y = tableTop;

    // En-tête du tableau
    doc.fontSize(10).font('Helvetica-Bold');
    doc.text('Date', 50, y);
    doc.text('Type', 50 + colWidths.date, y);
    doc.text('Paroisse', 50 + colWidths.date + colWidths.type, y);
    doc.text('Catégorie', 50 + colWidths.date + colWidths.type + colWidths.paroisse, y);
    doc.text('Description', 50 + colWidths.date + colWidths.type + colWidths.paroisse + colWidths.categorie, y);
    doc.text('Montant', 50 + colWidths.date + colWidths.type + colWidths.paroisse + colWidths.categorie + colWidths.desc, y);
    y += 20;

    // Ligne
    doc.moveTo(50, y).lineTo(700, y).stroke();
    y += 5;

    // Données
    doc.font('Helvetica').fontSize(9);
    let totalEntrees = 0, totalSorties = 0;

    result.rows.forEach(t => {
      if (y > 500) {
        doc.addPage();
        y = 50;
      }
      doc.text(new Date(t.date_transaction).toLocaleDateString('fr-FR'), 50, y);
      doc.text(t.type === 'entree' ? 'Entrée' : 'Sortie', 50 + colWidths.date, y);
      doc.text((t.paroisse || '').substring(0, 25), 50 + colWidths.date + colWidths.type, y);
      doc.text((t.categorie || '').substring(0, 20), 50 + colWidths.date + colWidths.type + colWidths.paroisse, y);
      doc.text((t.description || '-').substring(0, 40), 50 + colWidths.date + colWidths.type + colWidths.paroisse + colWidths.categorie, y);
      const montantTxt = `${t.type === 'entree' ? '+' : '-'}${parseFloat(t.montant).toLocaleString('fr-FR')} ${t.devise}`;
      doc.text(montantTxt, 50 + colWidths.date + colWidths.type + colWidths.paroisse + colWidths.categorie + colWidths.desc, y);
      y += 15;

      if (t.type === 'entree') totalEntrees += parseFloat(t.montant);
      else totalSorties += parseFloat(t.montant);
    });

    // Totaux
    y += 10;
    doc.moveTo(50, y).lineTo(700, y).stroke();
    y += 10;
    doc.font('Helvetica-Bold');
    doc.text('TOTAUX', 50, y);
    doc.text(`Entrées: +${totalEntrees.toLocaleString('fr-FR')} CDF`, 50 + colWidths.date + colWidths.type + colWidths.paroisse + colWidths.categorie, y);
    y += 15;
    doc.text(`Sorties: -${totalSorties.toLocaleString('fr-FR')} CDF`, 50 + colWidths.date + colWidths.type + colWidths.paroisse + colWidths.categorie, y);
    y += 15;
    doc.text(`Solde: ${(totalEntrees - totalSorties).toLocaleString('fr-FR')} CDF`, 50 + colWidths.date + colWidths.type + colWidths.paroisse + colWidths.categorie, y);

    doc.end();
  } catch (err) {
    console.error('Erreur export PDF:', err);
    req.flash('error', 'Erreur lors de l\'export');
    res.redirect('/transactions');
  }
});

/**
 * GET /transactions/export/excel - Export Excel
 */
router.get('/export/excel', async (req, res) => {
  try {
    const { paroisse_id, type, date_debut, date_fin } = req.query;
    let sql = `
      SELECT t.date_transaction, t.type, t.montant, t.devise, t.description, t.reference, t.mode_paiement,
             c.nom as categorie, p.nom as paroisse, p.niveau
      FROM transactions t
      LEFT JOIN categories_transactions c ON t.categorie_id = c.id
      LEFT JOIN paroisses p ON t.paroisse_id = p.id
      WHERE t.statut = 'valide'
    `;
    const params = [];
    if (paroisse_id) { params.push(paroisse_id); sql += ` AND t.paroisse_id = $${params.length}`; }
    if (type) { params.push(type); sql += ` AND t.type = $${params.length}`; }
    if (date_debut) { params.push(date_debut); sql += ` AND t.date_transaction >= $${params.length}`; }
    if (date_fin) { params.push(date_fin); sql += ` AND t.date_transaction <= $${params.length}`; }
    sql += ' ORDER BY t.date_transaction DESC';

    const result = await query(sql, params);

    const data = result.rows.map(t => ({
      'Date': t.date_transaction,
      'Type': t.type === 'entree' ? 'Entrée' : 'Sortie',
      'Niveau': t.niveau,
      'Paroisse/Entité': t.paroisse,
      'Catégorie': t.categorie,
      'Description': t.description,
      'Montant': parseFloat(t.montant),
      'Devise': t.devise,
      'Mode de paiement': t.mode_paiement,
      'Référence': t.reference
    }));

    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Transactions');

    // Ajout d'une feuille de totaux
    const totalEntrees = data.filter(t => t.Type === 'Entrée').reduce((s, t) => s + t.Montant, 0);
    const totalSorties = data.filter(t => t.Type === 'Sortie').reduce((s, t) => s + t.Montant, 0);
    const totaux = [
      { 'Indicateur': 'Total Entrées', 'Valeur': totalEntrees, 'Devise': 'CDF' },
      { 'Indicateur': 'Total Sorties', 'Valeur': totalSorties, 'Devise': 'CDF' },
      { 'Indicateur': 'Solde', 'Valeur': totalEntrees - totalSorties, 'Devise': 'CDF' }
    ];
    const wsTotaux = XLSX.utils.json_to_sheet(totaux);
    XLSX.utils.book_append_sheet(wb, wsTotaux, 'Totaux');

    const buffer = XLSX.write(wb, { bookType: 'xlsx', type: 'buffer' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="transactions-${Date.now()}.xlsx"`);
    res.send(buffer);
  } catch (err) {
    console.error('Erreur export Excel:', err);
    req.flash('error', 'Erreur lors de l\'export');
    res.redirect('/transactions');
  }
});

module.exports = router;
