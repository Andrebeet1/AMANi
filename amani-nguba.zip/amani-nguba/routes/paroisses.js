/**
 * Routes paroisses - Gestion de l'arborescence ecclésiastique
 * Paroisse → Branche → Brachet → Chapelle → Cellule
 */

const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

/**
 * GET /paroisses - Liste arborescente
 */
router.get('/', async (req, res) => {
  try {
    const result = await query(`
      WITH RECURSIVE arborescence AS (
        SELECT id, uuid, nom, niveau, parent_id, adresse, responsable, telephone, email,
               0 as profondeur, ARRAY[nom] as chemin
        FROM paroisses
        WHERE parent_id IS NULL

        UNION ALL

        SELECT p.id, p.uuid, p.nom, p.niveau, p.parent_id, p.adresse, p.responsable,
               p.telephone, p.email,
               a.profondeur + 1, a.chemin || p.nom
        FROM paroisses p
        INNER JOIN arborescence a ON p.parent_id = a.id
      )
      SELECT a.*,
             (SELECT COUNT(*) FROM transactions t WHERE t.paroisse_id = a.id AND t.statut = 'valide') as nb_transactions,
             COALESCE((SELECT SUM(CASE WHEN type = 'entree' THEN montant ELSE -montant END)
                       FROM transactions WHERE paroisse_id = a.id AND statut = 'valide'), 0) as solde
      FROM arborescence a
      ORDER BY chemin
    `);

    // Grouper par parent pour affichage hiérarchique
    const arborescence = result.rows;

    res.render('paroisses/index', {
      title: 'Arborescence ecclésiastique',
      paroisses: arborescence
    });
  } catch (err) {
    console.error('Erreur paroisses:', err);
    req.flash('error', 'Erreur lors du chargement');
    res.redirect('/dashboard');
  }
});

/**
 * GET /paroisses/arborescence - Vue arborescente
 */
router.get('/arborescence', async (req, res) => {
  try {
    const result = await query(`
      WITH RECURSIVE arborescence AS (
        SELECT id, uuid, nom, niveau, parent_id, adresse, responsable, telephone, email,
               0 as profondeur
        FROM paroisses
        WHERE parent_id IS NULL

        UNION ALL

        SELECT p.id, p.uuid, p.nom, p.niveau, p.parent_id, p.adresse, p.responsable,
               p.telephone, p.email,
               a.profondeur + 1
        FROM paroisses p
        INNER JOIN arborescence a ON p.parent_id = a.id
      )
      SELECT * FROM arborescence
      ORDER BY profondeur, nom
    `);

    // Construction d'un arbre
    const map = {};
    const roots = [];
    result.rows.forEach(p => {
      map[p.id] = { ...p, enfants: [] };
    });
    result.rows.forEach(p => {
      if (p.parent_id && map[p.parent_id]) {
        map[p.parent_id].enfants.push(map[p.id]);
      } else {
        roots.push(map[p.id]);
      }
    });

    res.render('paroisses/arborescence', {
      title: 'Vue arborescente',
      arbre: roots
    });
  } catch (err) {
    console.error('Erreur arborescence:', err);
    req.flash('error', 'Erreur lors du chargement');
    res.redirect('/paroisses');
  }
});

/**
 * GET /paroisses/new - Formulaire de création
 */
router.get('/new', async (req, res) => {
  try {
    const parents = await query(
      'SELECT id, nom, niveau FROM paroisses WHERE actif = true ORDER BY niveau, nom'
    );
    res.render('paroisses/form', {
      title: 'Nouvelle entité',
      paroisse: null,
      parents: parents.rows,
      action: '/paroisses'
    });
  } catch (err) {
    console.error('Erreur form paroisse:', err);
    req.flash('error', 'Erreur');
    res.redirect('/paroisses');
  }
});

/**
 * POST /paroisses - Créer une entité
 */
router.post('/', async (req, res) => {
  try {
    const { nom, niveau, parent_id, adresse, responsable, telephone, email, date_creation } = req.body;

    if (!nom || !niveau) {
      req.flash('error', 'Nom et niveau sont obligatoires');
      return res.redirect('/paroisses/new');
    }

    // Validation : cellule doit avoir un parent, etc.
    if (niveau !== 'paroisse' && !parent_id) {
      req.flash('error', 'Une entité non-paroisse doit avoir un parent');
      return res.redirect('/paroisses/new');
    }

    const result = await query(
      `INSERT INTO paroisses (nom, niveau, parent_id, adresse, responsable, telephone, email, date_creation)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id`,
      [nom, niveau, parent_id || null, adresse || null, responsable || null, telephone || null, email || null, date_creation || null]
    );

    req.flash('success', `${niveau.charAt(0).toUpperCase() + niveau.slice(1)} "${nom}" créé(e) avec succès`);
    res.redirect('/paroisses');
  } catch (err) {
    console.error('Erreur création paroisse:', err);
    req.flash('error', 'Erreur lors de la création');
    res.redirect('/paroisses/new');
  }
});

/**
 * GET /paroisses/:id - Détail d'une entité
 */
router.get('/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);

    const paroisseRes = await query(
      `SELECT p.*, parent.nom as parent_nom, parent.niveau as parent_niveau
       FROM paroisses p
       LEFT JOIN paroisses parent ON p.parent_id = parent.id
       WHERE p.id = $1`,
      [id]
    );

    if (paroisseRes.rows.length === 0) {
      req.flash('error', 'Entité non trouvée');
      return res.redirect('/paroisses');
    }

    const enfants = await query(
      'SELECT id, nom, niveau FROM paroisses WHERE parent_id = $1 ORDER BY niveau, nom',
      [id]
    );

    const stats = await query(`
      SELECT
        COALESCE(SUM(CASE WHEN type = 'entree' THEN montant ELSE 0 END), 0) as total_entrees,
        COALESCE(SUM(CASE WHEN type = 'sortie' THEN montant ELSE 0 END), 0) as total_sorties,
        COUNT(*) as nb_transactions
      FROM transactions
      WHERE paroisse_id = $1 AND statut = 'valide'
    `, [id]);

    const membres = await query(
      `SELECT id, nom, postnom, prenom, email, role, telephone
       FROM users
       WHERE paroisse_id = $1 AND actif = true
       ORDER BY role, nom`,
      [id]
    );

    res.render('paroisses/detail', {
      title: paroisseRes.rows[0].nom,
      paroisse: paroisseRes.rows[0],
      enfants: enfants.rows,
      stats: stats.rows[0],
      membres: membres.rows
    });
  } catch (err) {
    console.error('Erreur détail paroisse:', err);
    req.flash('error', 'Erreur');
    res.redirect('/paroisses');
  }
});

/**
 * GET /paroisses/:id/edit - Formulaire d'édition
 */
router.get('/:id/edit', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const paroisseRes = await query('SELECT * FROM paroisses WHERE id = $1', [id]);

    if (paroisseRes.rows.length === 0) {
      req.flash('error', 'Entité non trouvée');
      return res.redirect('/paroisses');
    }

    const parents = await query(
      'SELECT id, nom, niveau FROM paroisses WHERE id != $1 AND actif = true ORDER BY niveau, nom',
      [id]
    );

    res.render('paroisses/form', {
      title: 'Modifier',
      paroisse: paroisseRes.rows[0],
      parents: parents.rows,
      action: `/paroisses/${id}`
    });
  } catch (err) {
    console.error('Erreur édition:', err);
    req.flash('error', 'Erreur');
    res.redirect('/paroisses');
  }
});

/**
 * POST /paroisses/:id - Mettre à jour
 */
router.post('/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { nom, parent_id, adresse, responsable, telephone, email, date_creation, actif } = req.body;

    await query(
      `UPDATE paroisses
       SET nom = $1, parent_id = $2, adresse = $3, responsable = $4,
           telephone = $5, email = $6, date_creation = $7, actif = $8
       WHERE id = $9`,
      [nom, parent_id || null, adresse || null, responsable || null, telephone || null, email || null, date_creation || null, actif === 'on', id]
    );

    req.flash('success', 'Entité mise à jour avec succès');
    res.redirect(`/paroisses/${id}`);
  } catch (err) {
    console.error('Erreur mise à jour:', err);
    req.flash('error', 'Erreur lors de la mise à jour');
    res.redirect(`/paroisses/${req.params.id}/edit`);
  }
});

/**
 * POST /paroisses/:id/delete - Supprimer
 */
router.post('/:id/delete', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await query('DELETE FROM paroisses WHERE id = $1', [id]);
    req.flash('success', 'Entité supprimée');
    res.redirect('/paroisses');
  } catch (err) {
    console.error('Erreur suppression:', err);
    req.flash('error', 'Impossible de supprimer (entité avec enfants ou transactions)');
    res.redirect('/paroisses');
  }
});

/**
 * GET /paroisses/api/list - API JSON pour AJAX
 */
router.get('/api/list', async (req, res) => {
  try {
    const { niveau, parent_id } = req.query;
    let sql = 'SELECT id, nom, niveau, parent_id FROM paroisses WHERE actif = true';
    const params = [];
    if (niveau) {
      params.push(niveau);
      sql += ` AND niveau = $${params.length}`;
    }
    if (parent_id) {
      params.push(parent_id);
      sql += ` AND parent_id = $${params.length}`;
    }
    sql += ' ORDER BY nom';
    const result = await query(sql, params);
    res.json(result.rows);
  } catch (err) {
    console.error('Erreur API paroisses:', err);
    res.status(500).json({ error: 'Erreur serveur' });
  }
});

module.exports = router;
