/**
 * Routes budgets - Budgets prévisionnels
 */

const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

/**
 * GET /budgets - Liste des budgets
 */
router.get('/', async (req, res) => {
  try {
    const { annee, paroisse_id, type } = req.query;
    const currentYear = new Date().getFullYear();
    const filterYear = annee || currentYear;

    let sql = `
      SELECT b.*, c.nom as categorie_nom, p.nom as paroisse_nom, p.niveau,
             COALESCE((
               SELECT SUM(t.montant)
               FROM transactions t
               WHERE t.paroisse_id = b.paroisse_id
               AND t.categorie_id = b.categorie_id
               AND t.type = b.type
               AND t.statut = 'valide'
               AND EXTRACT(YEAR FROM t.date_transaction)::INTEGER = b.annee
             ), 0) as realise
      FROM budgets b
      LEFT JOIN categories_transactions c ON b.categorie_id = c.id
      LEFT JOIN paroisses p ON b.paroisse_id = p.id
      WHERE b.annee = $1
    `;
    const params = [filterYear];
    if (paroisse_id) { params.push(paroisse_id); sql += ` AND b.paroisse_id = $${params.length}`; }
    if (type) { params.push(type); sql += ` AND b.type = $${params.length}`; }
    sql += ' ORDER BY p.nom, b.type, c.nom';

    const budgets = await query(sql, params);

    // Statistiques par paroisse
    const stats = await query(`
      SELECT p.id, p.nom, p.niveau,
             COALESCE(SUM(CASE WHEN b.type = 'entree' THEN b.montant_prevu ELSE 0 END), 0) as budget_entrees,
             COALESCE(SUM(CASE WHEN b.type = 'sortie' THEN b.montant_prevu ELSE 0 END), 0) as budget_sorties
      FROM paroisses p
      LEFT JOIN budgets b ON b.paroisse_id = p.id AND b.annee = $1
      GROUP BY p.id, p.nom, p.niveau
      ORDER BY p.niveau, p.nom
    `, [filterYear]);

    const paroisses = await query('SELECT id, nom, niveau FROM paroisses WHERE actif = true ORDER BY niveau, nom');
    const categories = await query('SELECT id, nom, type FROM categories_transactions ORDER BY type, nom');

    res.render('budgets/index', {
      title: `Budgets ${filterYear}`,
      budgets: budgets.rows,
      stats: stats.rows,
      paroisses: paroisses.rows,
      categories: categories.rows,
      annee: parseInt(filterYear),
      filtres: req.query
    });
  } catch (err) {
    console.error('Erreur budgets:', err);
    req.flash('error', 'Erreur lors du chargement');
    res.redirect('/dashboard');
  }
});

/**
 * POST /budgets - Créer ou mettre à jour un budget
 */
router.post('/', async (req, res) => {
  try {
    const { paroisse_id, categorie_id, annee, mois, type, montant_prevu, description } = req.body;

    if (!paroisse_id || !type || !montant_prevu || !annee) {
      req.flash('error', 'Champs obligatoires manquants');
      return res.redirect('/budgets');
    }

    // Upsert (insert or update)
    await query(
      `INSERT INTO budgets (paroisse_id, categorie_id, annee, mois, type, montant_prevu, description, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       ON CONFLICT DO NOTHING`,
      [paroisse_id, categorie_id || null, annee, mois || null, type, montant_prevu, description || null, req.session.user.id]
    );

    req.flash('success', 'Budget enregistré');
    res.redirect(`/budgets?annee=${annee}`);
  } catch (err) {
    console.error('Erreur création budget:', err);
    req.flash('error', 'Erreur lors de l\'enregistrement');
    res.redirect('/budgets');
  }
});

/**
 * GET /budgets/rapport - Rapport budget vs réalisé
 */
router.get('/rapport', async (req, res) => {
  try {
    const { annee, paroisse_id } = req.query;
    const currentYear = new Date().getFullYear();
    const filterYear = annee || currentYear;

    const rapport = await query(`
      SELECT
        c.nom as categorie,
        b.type,
        b.montant_prevu,
        COALESCE((
          SELECT SUM(t.montant)
          FROM transactions t
          WHERE t.categorie_id = c.id
          AND t.paroisse_id = $2
          AND t.type = b.type
          AND t.statut = 'valide'
          AND EXTRACT(YEAR FROM t.date_transaction)::INTEGER = $1
        ), 0) as realise,
        b.montant_prevu - COALESCE((
          SELECT SUM(t.montant)
          FROM transactions t
          WHERE t.categorie_id = c.id
          AND t.paroisse_id = $2
          AND t.type = b.type
          AND t.statut = 'valide'
          AND EXTRACT(YEAR FROM t.date_transaction)::INTEGER = $1
        ), 0) as ecart
      FROM budgets b
      LEFT JOIN categories_transactions c ON b.categorie_id = c.id
      WHERE b.annee = $1 AND b.paroisse_id = $2
      ORDER BY b.type, c.nom
    `, [filterYear, paroisse_id || req.session.user.paroisse_id]);

    res.render('budgets/rapport', {
      title: 'Rapport Budget vs Réalisé',
      rapport: rapport.rows,
      annee: parseInt(filterYear)
    });
  } catch (err) {
    console.error('Erreur rapport budget:', err);
    req.flash('error', 'Erreur');
    res.redirect('/budgets');
  }
});

module.exports = router;
