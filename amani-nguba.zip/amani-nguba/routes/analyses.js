/**
 * Routes analyses - Statistiques et analyses approfondies
 */

const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

/**
 * GET /analyses - Page d'analyses
 */
router.get('/', async (req, res) => {
  try {
    const { annee, paroisse_id, niveau } = req.query;
    const filterYear = annee || new Date().getFullYear();

    // Construction de la requête avec filtres
    let whereClause = `WHERE t.statut = 'valide' AND EXTRACT(YEAR FROM t.date_transaction) = $1`;
    const params = [filterYear];
    if (paroisse_id) {
      params.push(paroisse_id);
      whereClause += ` AND t.paroisse_id = $${params.length}`;
    }
    if (niveau) {
      params.push(niveau);
      whereClause += ` AND p.niveau = $${params.length}`;
    }

    // Répartition par catégorie
    const repartitionCategories = await query(`
      SELECT c.nom, t.type, SUM(t.montant) as total
      FROM transactions t
      JOIN categories_transactions c ON t.categorie_id = c.id
      JOIN paroisses p ON t.paroisse_id = p.id
      ${whereClause}
      GROUP BY c.nom, t.type
      ORDER BY total DESC
    `, params);

    // Répartition par mode de paiement
    const modesPaiement = await query(`
      SELECT
        COALESCE(t.mode_paiement, 'non_specifie') as mode,
        COUNT(*) as nb_transactions,
        SUM(t.montant) as total
      FROM transactions t
      JOIN paroisses p ON t.paroisse_id = p.id
      ${whereClause}
      GROUP BY mode
      ORDER BY total DESC
    `, params);

    // Comparaison par niveau
    const comparaisonNiveaux = await query(`
      SELECT p.niveau,
        COUNT(DISTINCT p.id) as nb_entites,
        COALESCE(SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END), 0) as entrees,
        COALESCE(SUM(CASE WHEN t.type = 'sortie' THEN t.montant ELSE 0 END), 0) as sorties
      FROM paroisses p
      LEFT JOIN transactions t ON t.paroisse_id = p.id
        AND t.statut = 'valide'
        AND EXTRACT(YEAR FROM t.date_transaction) = $1
      ${niveau ? `WHERE p.niveau = $2` : ''}
      GROUP BY p.niveau
      ORDER BY p.niveau
    `, niveau ? [filterYear, niveau] : [filterYear]);

    // Top 10 entités par revenu
    const topEntites = await query(`
      SELECT p.nom, p.niveau,
        COALESCE(SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END), 0) as entrees,
        COALESCE(SUM(CASE WHEN t.type = 'sortie' THEN t.montant ELSE 0 END), 0) as sorties,
        COALESCE(SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE -t.montant END), 0) as solde
      FROM paroisses p
      LEFT JOIN transactions t ON t.paroisse_id = p.id
        AND t.statut = 'valide'
        AND EXTRACT(YEAR FROM t.date_transaction) = $1
      ${niveau ? `WHERE p.niveau = $2` : ''}
      GROUP BY p.id, p.nom, p.niveau
      ORDER BY entrees DESC
      LIMIT 10
    `, niveau ? [filterYear, niveau] : [filterYear]);

    // Évolution mensuelle détaillée
    const evolution = await query(`
      SELECT
        EXTRACT(MONTH FROM t.date_transaction)::INTEGER as mois,
        SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END) as entrees,
        SUM(CASE WHEN t.type = 'sortie' THEN t.montant ELSE 0 END) as sorties
      FROM transactions t
      JOIN paroisses p ON t.paroisse_id = p.id
      ${whereClause}
      GROUP BY mois
      ORDER BY mois
    `, params);

    // Tendance trimestrielle
    const tendance = await query(`
      SELECT
        EXTRACT(QUARTER FROM t.date_transaction)::INTEGER as trimestre,
        SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END) as entrees,
        SUM(CASE WHEN t.type = 'sortie' THEN t.montant ELSE 0 END) as sorties
      FROM transactions t
      JOIN paroisses p ON t.paroisse_id = p.id
      ${whereClause}
      GROUP BY trimestre
      ORDER BY trimestre
    `, params);

    const paroisses = await query('SELECT id, nom, niveau FROM paroisses WHERE actif = true ORDER BY niveau, nom');

    res.render('analyses/index', {
      title: 'Analyses',
      repartitionCategories: repartitionCategories.rows,
      modesPaiement: modesPaiement.rows,
      comparaisonNiveaux: comparaisonNiveaux.rows,
      topEntites: topEntites.rows,
      evolution: evolution.rows,
      tendance: tendance.rows,
      paroisses: paroisses.rows,
      annee: parseInt(filterYear),
      filtres: req.query
    });
  } catch (err) {
    console.error('Erreur analyses:', err);
    req.flash('error', 'Erreur lors du chargement des analyses');
    res.redirect('/dashboard');
  }
});

/**
 * GET /analyses/rapport-mensuel - Rapport mensuel
 */
router.get('/rapport-mensuel', async (req, res) => {
  try {
    const { annee, mois, paroisse_id } = req.query;
    const now = new Date();
    const filterYear = annee || now.getFullYear();
    const filterMonth = mois || (now.getMonth() + 1);

    let whereClause = `
      WHERE t.statut = 'valide'
      AND EXTRACT(YEAR FROM t.date_transaction) = $1
      AND EXTRACT(MONTH FROM t.date_transaction) = $2
    `;
    const params = [filterYear, filterMonth];
    if (paroisse_id) {
      params.push(paroisse_id);
      whereClause += ` AND t.paroisse_id = $${params.length}`;
    }

    const rapport = await query(`
      SELECT
        c.nom as categorie,
        t.type,
        COUNT(*) as nb_transactions,
        SUM(t.montant) as total
      FROM transactions t
      JOIN categories_transactions c ON t.categorie_id = c.id
      ${whereClause}
      GROUP BY c.nom, t.type
      ORDER BY t.type, total DESC
    `, params);

    res.render('analyses/rapport-mensuel', {
      title: 'Rapport mensuel',
      rapport: rapport.rows,
      annee: parseInt(filterYear),
      mois: parseInt(filterMonth)
    });
  } catch (err) {
    console.error('Erreur rapport mensuel:', err);
    req.flash('error', 'Erreur');
    res.redirect('/analyses');
  }
});

module.exports = router;
