/**
 * Routes annonces
 */

const express = require('express');
const router = express.Router();
const { query } = require('../config/db');

/**
 * GET /annonces - Liste des annonces
 */
router.get('/', async (req, res) => {
  try {
    const { type, urgent } = req.query;

    let sql = `
      SELECT a.*, u.nom as auteur_nom, u.prenom as auteur_prenom, p.nom as paroisse_nom
      FROM annonces a
      LEFT JOIN users u ON a.auteur_id = u.id
      LEFT JOIN paroisses p ON a.paroisse_id = p.id
      WHERE a.publie = true
    `;
    const params = [];
    if (type) { params.push(type); sql += ` AND a.type = $${params.length}`; }
    if (urgent === '1') { sql += ` AND a.urgent = true`; }
    sql += ' ORDER BY a.urgent DESC, a.date_publication DESC, a.created_at DESC LIMIT 100';

    const annonces = await query(sql, params);

    res.render('annonces/index', {
      title: 'Annonces',
      annonces: annonces.rows,
      filtres: req.query
    });
  } catch (err) {
    console.error('Erreur annonces:', err);
    req.flash('error', 'Erreur');
    res.redirect('/dashboard');
  }
});

/**
 * GET /annonces/new - Formulaire
 */
router.get('/new', async (req, res) => {
  try {
    const paroisses = await query('SELECT id, nom, niveau FROM paroisses WHERE actif = true ORDER BY niveau, nom');
    res.render('annonces/form', {
      title: 'Nouvelle annonce',
      annonce: null,
      paroisses: paroisses.rows,
      action: '/annonces'
    });
  } catch (err) {
    console.error('Erreur form annonce:', err);
    req.flash('error', 'Erreur');
    res.redirect('/annonces');
  }
});

/**
 * POST /annonces - Créer
 */
router.post('/', async (req, res) => {
  try {
    const { titre, contenu, paroisse_id, type, date_publication, date_expiration, urgent } = req.body;

    if (!titre || !contenu || !date_publication) {
      req.flash('error', 'Titre, contenu et date de publication sont obligatoires');
      return res.redirect('/annonces/new');
    }

    await query(
      `INSERT INTO annonces (titre, contenu, paroisse_id, type, date_publication, date_expiration, urgent, publie, auteur_id)
       VALUES ($1, $2, $3, $4, $5, $6, $7, true, $8)`,
      [titre, contenu, paroisse_id || null, type || 'general', date_publication, date_expiration || null, urgent === 'on', req.session.user.id]
    );

    req.flash('success', 'Annonce publiée avec succès');
    res.redirect('/annonces');
  } catch (err) {
    console.error('Erreur création annonce:', err);
    req.flash('error', 'Erreur lors de la publication');
    res.redirect('/annonces/new');
  }
});

/**
 * GET /annonces/:id - Détail
 */
router.get('/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const result = await query(`
      SELECT a.*, u.nom as auteur_nom, u.prenom as auteur_prenom, p.nom as paroisse_nom
      FROM annonces a
      LEFT JOIN users u ON a.auteur_id = u.id
      LEFT JOIN paroisses p ON a.paroisse_id = p.id
      WHERE a.id = $1
    `, [id]);

    if (result.rows.length === 0) {
      req.flash('error', 'Annonce non trouvée');
      return res.redirect('/annonces');
    }

    res.render('annonces/detail', {
      title: result.rows[0].titre,
      annonce: result.rows[0]
    });
  } catch (err) {
    console.error('Erreur détail annonce:', err);
    req.flash('error', 'Erreur');
    res.redirect('/annonces');
  }
});

/**
 * POST /annonces/:id/delete - Supprimer
 */
router.post('/:id/delete', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await query('DELETE FROM annonces WHERE id = $1', [id]);
    req.flash('success', 'Annonce supprimée');
    res.redirect('/annonces');
  } catch (err) {
    console.error('Erreur suppression annonce:', err);
    req.flash('error', 'Erreur');
    res.redirect('/annonces');
  }
});

module.exports = router;
