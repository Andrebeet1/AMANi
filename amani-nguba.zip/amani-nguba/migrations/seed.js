/**
 * Script de peuplement (seed) de la base de données
 * Usage: node migrations/seed.js
 */

require('dotenv').config();
const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

async function seed() {
  try {
    console.log('🌱 Démarrage du seed...');

    // 1. Créer une paroisse mère si elle n'existe pas
    const paroisseRes = await pool.query(
      `INSERT INTO paroisses (nom, niveau, parent_id, adresse, responsable, date_creation)
       VALUES ($1, $2, NULL, $3, $4, CURRENT_DATE)
       ON CONFLICT DO NOTHING
       RETURNING id`,
      ['Paroisse AMANI NGUBA', 'paroisse', 'Kinshasa', 'Pasteur Titulaire']
    );

    let paroisseId;
    if (paroisseRes.rows.length > 0) {
      paroisseId = paroisseRes.rows[0].id;
      console.log('✅ Paroisse AMANI NGUBA créée');
    } else {
      const res = await pool.query(
        `SELECT id FROM paroisses WHERE nom = 'Paroisse AMANI NGUBA' AND niveau = 'paroisse' LIMIT 1`
      );
      paroisseId = res.rows[0].id;
      console.log('ℹ️  Paroisse AMANI NGUBA existe déjà');
    }

    // 2. Créer des exemples de branches
    const branches = [
      { nom: 'Branche Nord', adresse: 'Nord de la ville' },
      { nom: 'Branche Sud', adresse: 'Sud de la ville' },
      { nom: 'Branche Est', adresse: 'Est de la ville' }
    ];

    for (const b of branches) {
      await pool.query(
        `INSERT INTO paroisses (nom, niveau, parent_id, adresse, date_creation)
         VALUES ($1, 'branche', $2, $3, CURRENT_DATE)
         ON CONFLICT DO NOTHING`,
        [b.nom, paroisseId, b.adresse]
      );
    }
    console.log('✅ Branches créées');

    // 3. Créer un brachet exemple
    const brancheRes = await pool.query(
      `SELECT id FROM paroisses WHERE niveau = 'branche' LIMIT 1`
    );
    if (brancheRes.rows.length > 0) {
      await pool.query(
        `INSERT INTO paroisses (nom, niveau, parent_id, adresse, date_creation)
         VALUES ('Brachet Central', 'brachet', $1, 'Centre-ville', CURRENT_DATE)
         ON CONFLICT DO NOTHING`,
        [brancheRes.rows[0].id]
      );
    }
    console.log('✅ Brachets créés');

    // 4. Créer des chapelles
    const brachetRes = await pool.query(
      `SELECT id FROM paroisses WHERE niveau = 'brachet' LIMIT 1`
    );
    if (brachetRes.rows.length > 0) {
      const chapelles = [
        { nom: 'Chapelle de la Grâce', adresse: 'Quartier 1' },
        { nom: 'Chapelle de la Paix', adresse: 'Quartier 2' },
        { nom: 'Chapelle de la Lumière', adresse: 'Quartier 3' }
      ];
      for (const c of chapelles) {
        await pool.query(
          `INSERT INTO paroisses (nom, niveau, parent_id, adresse, date_creation)
           VALUES ($1, 'chapelle', $2, $3, CURRENT_DATE)
           ON CONFLICT DO NOTHING`,
          [c.nom, brachetRes.rows[0].id, c.adresse]
        );
      }
    }
    console.log('✅ Chapelles créées');

    // 5. Créer des cellules
    const chapelleRes = await pool.query(
      `SELECT id FROM paroisses WHERE niveau = 'chapelle' LIMIT 1`
    );
    if (chapelleRes.rows.length > 0) {
      const cellules = [
        { nom: 'Cellule Esther', adresse: 'Bloc A' },
        { nom: 'Cellule Daniel', adresse: 'Bloc B' },
        { nom: 'Cellule Pierre', adresse: 'Bloc C' }
      ];
      for (const ce of cellules) {
        await pool.query(
          `INSERT INTO paroisses (nom, niveau, parent_id, adresse, date_creation)
           VALUES ($1, 'cellule', $2, $3, CURRENT_DATE)
           ON CONFLICT DO NOTHING`,
          [ce.nom, chapelleRes.rows[0].id, ce.adresse]
        );
      }
    }
    console.log('✅ Cellules créées');

    // 6. Créer un utilisateur super admin
    const passwordHash = await bcrypt.hash('Admin2024!', 10);
    await pool.query(
      `INSERT INTO users (nom, postnom, prenom, email, password_hash, role, paroisse_id, sexe, date_adhesion)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_DATE)
       ON CONFLICT (email) DO NOTHING`,
      ['KABILA', 'MWANZA', 'Joseph', 'admin@amani-nguba.cd', passwordHash, 'super_admin', paroisseId, 'M']
    );
    console.log('✅ Super admin créé');

    // 7. Créer un utilisateur pasteur
    const pasteurHash = await bcrypt.hash('Pasteur2024!', 10);
    await pool.query(
      `INSERT INTO users (nom, postnom, prenom, email, password_hash, role, paroisse_id, sexe, date_adhesion)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_DATE)
       ON CONFLICT (email) DO NOTHING`,
      ['MUKENDI', 'NTUMBA', 'Pierre', 'pasteur@amani-nguba.cd', pasteurHash, 'pasteur', paroisseId, 'M']
    );
    console.log('✅ Pasteur créé');

    // 8. Créer un trésorier central
    const tresorierHash = await bcrypt.hash('Tresorier2024!', 10);
    await pool.query(
      `INSERT INTO users (nom, postnom, prenom, email, password_hash, role, paroisse_id, sexe, date_adhesion)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, CURRENT_DATE)
       ON CONFLICT (email) DO NOTHING`,
      ['NTUMBA', 'LUMUMBA', 'Marie', 'tresorier@amani-nguba.cd', tresorierHash, 'tresorier_central', paroisseId, 'F']
    );
    console.log('✅ Trésorier central créé');

    console.log('\n🎉 Seed terminé avec succès !');
    console.log('\n📋 Comptes créés :');
    console.log('   👤 Super Admin: admin@amani-nguba.cd / Admin2024!');
    console.log('   ⛪ Pasteur: pasteur@amani-nguba.cd / Pasteur2024!');
    console.log('   💰 Trésorier: tresorier@amani-nguba.cd / Tresorier2024!');
    console.log('\n⚠️  Changez ces mots de passe en production !');

    process.exit(0);
  } catch (err) {
    console.error('❌ Erreur lors du seed:', err.message);
    process.exit(1);
  }
}

seed();
