-- =====================================================
-- AMANI NGUBA - Schéma de base de données
-- CEPAC - Communauté Protestante
-- "Tout soit fait avec ordre et fidélité" (1 Co 14:40)
-- =====================================================

-- Extension pour UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =====================================================
-- TABLE: paroisses (niveau racine)
-- Structure: Paroisse Mère → Branches → Brachets → Chapelles → Cellules
-- =====================================================

-- Table unifiée pour l'arborescence ecclésiastique
CREATE TABLE IF NOT EXISTS paroisses (
  id SERIAL PRIMARY KEY,
  uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
  nom VARCHAR(150) NOT NULL,
  niveau VARCHAR(20) NOT NULL CHECK (niveau IN ('paroisse', 'branche', 'brachet', 'chapelle', 'cellule')),
  parent_id INTEGER REFERENCES paroisses(id) ON DELETE CASCADE,
  adresse TEXT,
  responsable VARCHAR(150),
  telephone VARCHAR(20),
  email VARCHAR(150),
  date_creation DATE,
  actif BOOLEAN DEFAULT true,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_paroisses_parent ON paroisses(parent_id);
CREATE INDEX idx_paroisses_niveau ON paroisses(niveau);

-- =====================================================
-- TABLE: users
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
  nom VARCHAR(100) NOT NULL,
  postnom VARCHAR(100),
  prenom VARCHAR(100),
  email VARCHAR(150) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(30) NOT NULL CHECK (role IN (
    'super_admin',     -- Administrateur système
    'pasteur',         -- Pasteur titulaire
    'tresorier_central',-- Trésorier de la paroisse mère
    'tresorier_branche',-- Trésorier d'une branche
    'tresorier_brachet',-- Trésorier d'un brachet
    'tresorier_chapelle',-- Trésorier d'une chapelle
    'secretaire',      -- Secrétaire
    'membre'           -- Membre/fidèle
  )),
  paroisse_id INTEGER REFERENCES paroisses(id),
  telephone VARCHAR(20),
  adresse TEXT,
  date_naissance DATE,
  date_adhesion DATE,
  sexe VARCHAR(1) CHECK (sexe IN ('M', 'F')),
  profession VARCHAR(100),
  actif BOOLEAN DEFAULT true,
  derniere_connexion TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_paroisse ON users(paroisse_id);
CREATE INDEX idx_users_role ON users(role);

-- =====================================================
-- TABLE: categories_transactions
-- =====================================================
CREATE TABLE IF NOT EXISTS categories_transactions (
  id SERIAL PRIMARY KEY,
  nom VARCHAR(100) NOT NULL,
  type VARCHAR(20) NOT NULL CHECK (type IN ('entree', 'sortie')),
  description TEXT,
  paroisse_id INTEGER REFERENCES paroisses(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Catégories par défaut
INSERT INTO categories_transactions (nom, type, description) VALUES
  ('Dîme', 'entree', 'Dîme (10% du revenu)'),
  ('Offrande de culte', 'entree', 'Offrande dominicale'),
  ('Offrande de prière', 'entree', 'Offrandes des séances de prière'),
  ('Offrande spéciale', 'entree', 'Collectes pour causes spéciales'),
  ('Don de mission', 'entree', 'Soutien aux œuvres missionnaires'),
  ('Don de construction', 'entree', 'Contributions pour les bâtiments'),
  ('Don de solidarité', 'entree', 'Aide aux nécessiteux'),
  ('Quête de mariage', 'entree', 'Offrandes lors des mariages'),
  ('Quête d''obsèques', 'entree', 'Offrandes lors des funérailles'),
  ('Quête de baptême', 'entree', 'Offrandes lors des baptêmes'),
  ('Salaire pasteur', 'sortie', 'Rémunération du pasteur'),
  ('Location', 'sortie', 'Loyer du lieu de culte'),
  ('Électricité', 'sortie', 'Factures d''électricité'),
  ('Eau', 'sortie', 'Factures d''eau'),
  ('Transport', 'sortie', 'Déplacements pastoraux'),
  ('Communication', 'sortie', 'Téléphone, internet'),
  ('Matériel', 'sortie', 'Achat de matériel'),
  ('Œuvres sociales', 'sortie', 'Aides aux démunis'),
  ('Mission', 'sortie', 'Soutien aux missions'),
  ('Formation', 'sortie', 'Séminaires, formations'),
  ('Entretien', 'sortie', 'Maintenance des locaux'),
  ('Autres', 'sortie', 'Autres dépenses');

-- =====================================================
-- TABLE: transactions
-- =====================================================
CREATE TABLE IF NOT EXISTS transactions (
  id SERIAL PRIMARY KEY,
  uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
  paroisse_id INTEGER NOT NULL REFERENCES paroisses(id),
  categorie_id INTEGER NOT NULL REFERENCES categories_transactions(id),
  user_id INTEGER REFERENCES users(id),
  type VARCHAR(20) NOT NULL CHECK (type IN ('entree', 'sortie')),
  montant DECIMAL(15, 2) NOT NULL CHECK (montant >= 0),
  devise VARCHAR(10) DEFAULT 'CDF',
  description TEXT,
  date_transaction DATE NOT NULL,
  mode_paiement VARCHAR(50) CHECK (mode_paiement IN ('especes', 'mobile_money', 'virement', 'cheque', 'nature')),
  reference VARCHAR(100),
  justificatif VARCHAR(255),
  statut VARCHAR(20) DEFAULT 'valide' CHECK (statut IN ('valide', 'en_attente', 'annule')),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_transactions_paroisse ON transactions(paroisse_id);
CREATE INDEX idx_transactions_date ON transactions(date_transaction);
CREATE INDEX idx_transactions_type ON transactions(type);
CREATE INDEX idx_transactions_categorie ON transactions(categorie_id);

-- =====================================================
-- TABLE: budgets
-- =====================================================
CREATE TABLE IF NOT EXISTS budgets (
  id SERIAL PRIMARY KEY,
  uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
  paroisse_id INTEGER NOT NULL REFERENCES paroisses(id),
  categorie_id INTEGER REFERENCES categories_transactions(id),
  annee INTEGER NOT NULL,
  mois INTEGER CHECK (mois BETWEEN 1 AND 12),
  type VARCHAR(20) NOT NULL CHECK (type IN ('entree', 'sortie')),
  montant_prevu DECIMAL(15, 2) NOT NULL,
  description TEXT,
  created_by INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_budgets_paroisse ON budgets(paroisse_id);
CREATE INDEX idx_budgets_annee ON budgets(annee);

-- =====================================================
-- TABLE: annonces
-- =====================================================
CREATE TABLE IF NOT EXISTS annonces (
  id SERIAL PRIMARY KEY,
  uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
  titre VARCHAR(200) NOT NULL,
  contenu TEXT NOT NULL,
  paroisse_id INTEGER REFERENCES paroisses(id),
  type VARCHAR(30) DEFAULT 'general' CHECK (type IN ('general', 'culte', 'activite', 'urgence', 'deces', 'mariage', 'naissance')),
  date_publication DATE NOT NULL,
  date_expiration DATE,
  urgent BOOLEAN DEFAULT false,
  publie BOOLEAN DEFAULT true,
  auteur_id INTEGER REFERENCES users(id),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_annonces_paroisse ON annonces(paroisse_id);
CREATE INDEX idx_annonces_date ON annonces(date_publication);

-- =====================================================
-- TABLE: recompenses (Fidèles de l'année - Novembre)
-- =====================================================
CREATE TABLE IF NOT EXISTS recompenses (
  id SERIAL PRIMARY KEY,
  uuid UUID DEFAULT uuid_generate_v4() UNIQUE,
  annee INTEGER NOT NULL,
  mois INTEGER NOT NULL,
  type_recompense VARCHAR(50) NOT NULL CHECK (type_recompense IN (
    'meilleur_mois_fidelite',     -- Meilleur du mois (fidélité)
    'meilleur_mois_revenu',       -- Meilleur du mois (revenu)
    'fidele_annee',               -- Fidèle de l'année
    'meilleur_revenu_annee',      -- Meilleur revenu de l'année
    'meilleur_trésorier'          -- Meilleur trésorier
  )),
  user_id INTEGER REFERENCES users(id),
  paroisse_id INTEGER REFERENCES paroisses(id),
  score DECIMAL(10, 2),
  motif TEXT,
  recompense VARCHAR(200),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_recompenses_annee ON recompenses(annee);
CREATE INDEX idx_recompenses_type ON recompenses(type_recompense);

-- =====================================================
-- TABLE: sessions (pour express-session)
-- =====================================================
CREATE TABLE IF NOT EXISTS "session" (
  "sid" varchar NOT NULL COLLATE "default",
  "sess" json NOT NULL,
  "expire" timestamp(6) NOT NULL
)
WITH (OIDS=FALSE);

ALTER TABLE "session" DROP CONSTRAINT IF EXISTS "session_pkey";
ALTER TABLE "session" ADD CONSTRAINT "session_pkey" PRIMARY KEY ("sid") NOT DEFERRABLE INITIALLY IMMEDIATE;
CREATE INDEX IF NOT EXISTS "IDX_session_expire" ON "session" ("expire");

-- =====================================================
-- VUES UTILES
-- =====================================================

-- Vue: soldes par paroisse
CREATE OR REPLACE VIEW v_soldes_paroisses AS
SELECT
  p.id,
  p.nom,
  p.niveau,
  COALESCE(SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END), 0) AS total_entrees,
  COALESCE(SUM(CASE WHEN t.type = 'sortie' THEN t.montant ELSE 0 END), 0) AS total_sorties,
  COALESCE(SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE -t.montant END), 0) AS solde
FROM paroisses p
LEFT JOIN transactions t ON t.paroisse_id = p.id AND t.statut = 'valide'
GROUP BY p.id, p.nom, p.niveau;

-- Vue: statistiques mensuelles
CREATE OR REPLACE VIEW v_stats_mensuelles AS
SELECT
  p.id AS paroisse_id,
  p.nom AS paroisse_nom,
  EXTRACT(YEAR FROM t.date_transaction)::INTEGER AS annee,
  EXTRACT(MONTH FROM t.date_transaction)::INTEGER AS mois,
  SUM(CASE WHEN t.type = 'entree' THEN t.montant ELSE 0 END) AS entrees,
  SUM(CASE WHEN t.type = 'sortie' THEN t.montant ELSE 0 END) AS sorties
FROM paroisses p
LEFT JOIN transactions t ON t.paroisse_id = p.id
WHERE t.statut = 'valide'
GROUP BY p.id, p.nom, annee, mois;

-- =====================================================
-- DONNÉES INITIALES (SEED)
-- =====================================================

-- Paroisse Mère AMANI NGUBA
INSERT INTO paroisses (nom, niveau, parent_id, adresse, responsable, date_creation)
VALUES ('Paroisse AMANI NGUBA', 'paroisse', NULL, 'Kinshasa', 'Pasteur Titulaire', CURRENT_DATE);

-- =====================================================
-- TRIGGERS
-- =====================================================

-- Mise à jour automatique de updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = CURRENT_TIMESTAMP;
  RETURN NEW;
END;
$$ language 'plpgsql';

DO $$
DECLARE
  t text;
BEGIN
  FOR t IN
    SELECT table_name FROM information_schema.tables
    WHERE table_schema = 'public'
    AND table_name IN ('users', 'paroisses', 'transactions', 'budgets', 'annonces', 'categories_transactions')
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS update_%I_updated_at ON %I', t, t);
    EXECUTE format('CREATE TRIGGER update_%I_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION update_updated_at_column()', t, t);
  END LOOP;
END $$;
