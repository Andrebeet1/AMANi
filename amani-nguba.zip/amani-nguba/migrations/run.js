/**
 * Script de migration de la base de données
 * Usage: node migrations/run.js
 */

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

async function runMigrations() {
  try {
    console.log('🔄 Démarrage des migrations...');

    const migrationsDir = __dirname;
    const files = fs.readdirSync(migrationsDir)
      .filter(f => f.endsWith('.sql'))
      .sort();

    for (const file of files) {
      console.log(`📄 Exécution de ${file}...`);
      const sql = fs.readFileSync(path.join(migrationsDir, file), 'utf8');
      await pool.query(sql);
      console.log(`✅ ${file} terminé`);
    }

    console.log('🎉 Toutes les migrations ont été appliquées avec succès');
    process.exit(0);
  } catch (err) {
    console.error('❌ Erreur lors des migrations:', err.message);
    process.exit(1);
  }
}

runMigrations();
