#!/bin/bash
# =====================================================
# AMANI NGUBA - Script d'installation et de démarrage
# =====================================================

set -e

echo ""
echo "⛪  AMANI NGUBA - Installation"
echo "================================"
echo ""

# Couleurs
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Vérifier Node
if ! command -v node &> /dev/null; then
    echo -e "${RED}❌ Node.js n'est pas installé.${NC}"
    echo "Téléchargez-le sur https://nodejs.org/"
    exit 1
fi

NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
if [ "$NODE_VERSION" -lt 18 ]; then
    echo -e "${YELLOW}⚠️  Node 18+ recommandé (vous avez $(node -v))${NC}"
fi

echo -e "${BLUE}📦 Installation des dépendances...${NC}"
npm install

# Créer .env s'il n'existe pas
if [ ! -f .env ]; then
    echo -e "${BLUE}📝 Création du fichier .env...${NC}"
    cp .env.example .env
    SESSION_SECRET=$(openssl rand -hex 32 2>/dev/null || echo "amani-nguba-secret-$(date +%s)")
    sed -i "s|SESSION_SECRET=.*|SESSION_SECRET=$SESSION_SECRET|" .env
    echo -e "${YELLOW}⚠️  N'oubliez pas de configurer DATABASE_URL dans .env${NC}"
fi

echo ""
echo -e "${GREEN}✅ Installation terminée !${NC}"
echo ""
echo "📋 Prochaines étapes :"
echo "  1. Configurer PostgreSQL et DATABASE_URL dans .env"
echo "  2. Lancer les migrations : npm run migrate"
echo "  3. Insérer les données initiales : npm run seed"
echo "  4. Démarrer le serveur : npm start"
echo ""
echo "🌐 L'application sera accessible sur http://localhost:3000"
echo ""
