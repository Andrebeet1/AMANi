/**
 * AMANI NGUBA - Serveur principal
 * Plateforme de gestion financière et pastorale - CEPAC
 * "La paix profonde dans la gestion fidèle"
 */

require('dotenv').config();
const express = require('express');
const session = require('express-session');
const PgSession = require('connect-pg-simple')(session);
const flash = require('connect-flash');
const path = require('path');
const { Pool } = require('pg');

const app = express();
const PORT = process.env.PORT || 3000;

// Configuration de la base de données
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

// Vérification de la connexion
pool.connect((err, client, release) => {
  if (err) {
    console.error('❌ Erreur connexion DB:', err.message);
  } else {
    console.log('✅ Base de données connectée');
    release();
  }
});

// Middlewares globaux
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Session
app.use(session({
  store: new PgSession({
    pool: pool,
    tableName: 'session'
  }),
  secret: process.env.SESSION_SECRET || 'amani-nguba-secret-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 1000 * 60 * 60 * 24 * 7, // 7 jours
    secure: process.env.NODE_ENV === 'production'
  }
}));

app.use(flash());

// Variables globales pour les vues
app.use((req, res, next) => {
  res.locals.user = req.session.user || null;
  res.locals.success = req.flash('success');
  res.locals.error = req.flash('error');
  res.locals.currentPath = req.path;
  next();
});

// Middleware d'authentification
const requireAuth = (req, res, next) => {
  if (!req.session.user) {
    req.flash('error', 'Veuillez vous connecter pour accéder à cette page');
    return res.redirect('/login');
  }
  next();
};

const requireRole = (...roles) => {
  return (req, res, next) => {
    if (!req.session.user || !roles.includes(req.session.user.role)) {
      req.flash('error', 'Accès non autorisé');
      return res.redirect('/dashboard');
    }
    next();
  };
};

// Rendre le pool accessible dans req
app.use((req, res, next) => {
  req.db = pool;
  next();
});

// Routes
app.use('/auth', require('./routes/auth'));
app.use('/dashboard', requireAuth, require('./routes/dashboard'));
app.use('/paroisses', requireAuth, require('./routes/paroisses'));
app.use('/transactions', requireAuth, require('./routes/transactions'));
app.use('/budgets', requireAuth, require('./routes/budgets'));
app.use('/annonces', requireAuth, require('./routes/annonces'));
app.use('/analyses', requireAuth, require('./routes/analyses'));
app.use('/recompenses', requireAuth, require('./routes/recompenses'));

// Page d'accueil
app.get('/', (req, res) => {
  if (req.session.user) {
    return res.redirect('/dashboard');
  }
  res.render('auth/landing', { title: 'AMANI NGUBA - Plateforme de gestion' });
});

// Gestion 404
app.use((req, res) => {
  res.status(404).render('errors/404', { title: 'Page non trouvée' });
});

// Gestion d'erreurs
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('errors/500', {
    title: 'Erreur serveur',
    error: process.env.NODE_ENV === 'development' ? err : {}
  });
});

app.listen(PORT, () => {
  console.log(`🚀 AMANI NGUBA démarré sur le port ${PORT}`);
  console.log(`📖 http://localhost:${PORT}`);
});
