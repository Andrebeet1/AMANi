/**
 * AMANI NGUBA - JavaScript principal
 * jQuery + AJAX + Bootstrap 5
 */

$(document).ready(function() {

  // Auto-dismiss alerts after 5 seconds
  setTimeout(function() {
    $('.alert-dismissible').fadeOut('slow');
  }, 5000);

  // Confirmation de suppression
  $('form[data-confirm]').on('submit', function(e) {
    if (!confirm($(this).data('confirm'))) {
      e.preventDefault();
    }
  });

  // Boutons de confirmation
  $('[data-confirm-button]').on('click', function(e) {
    if (!confirm($(this).data('confirm-button'))) {
      e.preventDefault();
    }
  });

  // Formatage des montants en direct
  $('input[data-type="montant"]').on('input', function() {
    let value = $(this).val().replace(/[^\d.]/g, '');
    $(this).val(value);
  });

  // Filtrage dynamique des transactions
  let filterTimeout;
  $('#filter-form input, #filter-form select').on('change input', function() {
    clearTimeout(filterTimeout);
    filterTimeout = setTimeout(function() {
      $('#filter-form').submit();
    }, 500);
  });

  // Graphiques : couleur primaire
  window.AMANI_COLORS = {
    primary: '#1e3a5f',
    accent: '#2c5282',
    secondary: '#c9a961',
    success: '#2f855a',
    danger: '#c53030',
    warning: '#d69e2e',
    info: '#3182ce',
    light: '#f7fafc',
    muted: '#718096'
  };

  // Tooltip Bootstrap
  var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
  tooltipTriggerList.map(function (el) { return new bootstrap.Tooltip(el); });

  // Soumission de formulaires avec AJAX (exemple pour transactions)
  $('form[data-ajax]').on('submit', function(e) {
    e.preventDefault();
    var $form = $(this);
    var $btn = $form.find('button[type="submit"]');
    var originalText = $btn.html();
    $btn.prop('disabled', true).html('<i class="bi bi-hourglass-split"></i> Traitement...');

    $.ajax({
      url: $form.attr('action'),
      method: $form.attr('method'),
      data: $form.serialize(),
      success: function(response) {
        if (response.success) {
          // Afficher message de succès
          showAlert('success', response.message || 'Opération réussie');
          if (response.redirect) {
            setTimeout(function() { window.location.href = response.redirect; }, 1000);
          } else {
            setTimeout(function() { location.reload(); }, 1000);
          }
        } else {
          showAlert('danger', response.message || 'Erreur');
        }
      },
      error: function() {
        showAlert('danger', 'Erreur de communication avec le serveur');
      },
      complete: function() {
        $btn.prop('disabled', false).html(originalText);
      }
    });
  });

  function showAlert(type, message) {
    var alertHtml = `<div class="alert alert-${type} alert-dismissible fade show" role="alert">
      ${message}
      <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>`;
    $('#alerts-container').prepend(alertHtml);
    setTimeout(function() {
      $('#alerts-container .alert').first().fadeOut('slow', function() { $(this).remove(); });
    }, 5000);
  }

  // Actualisation automatique des soldes toutes les 60 secondes
  if ($('#auto-refresh').length) {
    setInterval(function() {
      $.get('/dashboard/api/stats', function(data) {
        // Mise à jour discrète des statistiques si nécessaire
        console.log('Stats actualisées', data);
      });
    }, 60000);
  }

  // Conversion CDF/USD (taux indicatif)
  $('[data-convert]').on('click', function() {
    var $btn = $(this);
    var target = $btn.data('convert');
    var taux = 2800; // 1 USD = 2800 CDF (indicatif)
    $('[data-montant]').each(function() {
      var $el = $(this);
      var cdf = parseFloat($el.data('montant'));
      if (target === 'usd') {
        $el.text('$' + (cdf / taux).toFixed(2));
      } else {
        $el.text(cdf.toLocaleString('fr-FR') + ' CDF');
      }
    });
    $btn.data('convert', target === 'usd' ? 'cdf' : 'usd');
    $btn.text(target === 'usd' ? 'Voir en CDF' : 'Voir en USD');
  });

  // Animation des trophées (récompenses)
  $('.trophy-card').on('mouseenter', function() {
    $(this).find('.trophy-icon').css('transform', 'rotate(-10deg) scale(1.1)');
  }).on('mouseleave', function() {
    $(this).find('.trophy-icon').css('transform', 'rotate(0) scale(1)');
  });

  $('.trophy-icon').css('transition', 'transform 0.3s ease');

  // Initialisation des datepickers
  $('input[type="date"]').attr('max', new Date().toISOString().split('T')[0]);

  // Print
  $('[data-print]').on('click', function() {
    window.print();
  });

});
