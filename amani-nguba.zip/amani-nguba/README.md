# ⛪ AMANI NGUBA — Plateforme de gestion paroissiale

> **« La paix profonde dans la gestion fidèle »**
> Application web de gestion financière et pastorale pour la **Communauté Protestante CEPAC**.

---

## 🎯 À propos

**AMANI NGUBA** est une plateforme complète de gestion à distance, conçue pour digitaliser et centraliser la gestion financière et administrative d'une église locale CEPAC (Communauté Église du Christ au Congo), avec son organisation hiérarchique :

```
Paroisse Mère
  └── Branches
        └── Brachets
              └── Chapelles
                    └── Cellules
```

L'application respecte la philosophie protestante : **transparence**, **fidélité**, **sagesse** et **solidarité** dans la gestion des ressources.

---

## ✨ Fonctionnalités

### 📊 Tableau de bord
- Vue d'ensemble des finances du mois et de l'année
- Graphiques d'évolution mensuelle (Chart.js)
- Top catégories d'entrées
- Dernières transactions
- Annonces récentes
- Vue par niveau hiérarchique

### 💰 Transactions
- Enregistrement entrées / sorties avec AJAX
- 22 catégories pré-configurées (dîme, offrande, don mission, etc.)
- Modes de paiement : espèces, mobile money, virement, chèque, nature
- Filtres avancés (entité, type, date, recherche)
- Export **PDF** et **Excel** des rapports
- Annulation traçable

### 📋 Budgets
- Budgets prévisionnels annuels et mensuels
- Suivi **budget vs réalisé** en temps réel
- Barres de progression par catégorie
- Rapport détaillé imprimable

### 📈 Analyses
- Évolution mensuelle (entrées/sorties)
- Tendance trimestrielle
- Répartition par mode de paiement
- Comparaison par niveau hiérarchique
- Top 10 entités par revenu

### 📢 Annonces
- Publication d'annonces internes
- Types : général, culte, activité, urgence, décès, mariage, naissance
- Niveaux de priorité (urgent en évidence)
- Filtrage et expiration automatique

### 🏆 Récompenses (Fidèles de l'année)
- **Podium des 3 meilleurs fidèles** de l'année
- **Meilleur du mois** (fidélité + revenu)
- Cérémonies de **novembre** mises en valeur
- Système de scores automatique
- Attribution de récompenses personnalisées

### 🏛️ Organisation
- Gestion de l'arborescence complète
- **Vue liste** et **vue arborescente** (drill-down)
- Création / édition de chaque entité
- Statistiques par entité
- Membres rattachés

### 🔐 Sécurité
- Authentification par session (PostgreSQL-backed)
- 8 rôles utilisateurs (super admin, pasteur, trésoriers par niveau, secrétaire, membre)
- Mots de passe hashés (bcrypt)
- Sessions sécurisées en production (HTTPS, cookies httpOnly)

---

## 🛠️ Stack technique

| Composant | Technologie |
|-----------|-------------|
| Backend   | Node.js 18+ / Express.js |
| Templates | EJS (server-side rendering) |
| Frontend  | Bootstrap 5.3 + jQuery 3 + Chart.js 4 |
| Database  | PostgreSQL 15 |
| Auth      | express-session + connect-pg-simple |
| PDF       | PDFKit |
| Excel     | SheetJS (xlsx) |
| Déploiement | Render.com (gratuit) |

---

## 🚀 Installation

### Prérequis
- **Node.js 18+** ([télécharger](https://nodejs.org/))
- **PostgreSQL 15+** ([télécharger](https://www.postgresql.org/download/))
- **Git** ([télécharger](https://git-scm.com/))

### Étapes

```bash
# 1. Cloner ou extraire le projet
cd amani-nguba

# 2. Lancer le script d'installation
chmod +x scripts/setup.sh
./scripts/setup.sh

# 3. Configurer la base de données dans .env
# Éditer le fichier .env :
#    DATABASE_URL=postgres://user:password@localhost:5432/amani_nguba

# 4. Créer la base de données
createdb amani_nguba

# 5. Lancer les migrations
npm run migrate

# 6. Insérer les données de démo
npm run seed

# 7. Démarrer le serveur
npm start
```

L'application sera accessible sur **http://localhost:3000**

### 🔑 Comptes par défaut (après `npm run seed`)

| Rôle | Email | Mot de passe |
|------|-------|--------------|
| Super Admin | `admin@amani-nguba.cd` | `Admin2024!` |
| Pasteur | `pasteur@amani-nguba.cd` | `Pasteur2024!` |
| Trésorier central | `tresorier@amani-nguba.cd` | `Tresorier2024!` |

> ⚠️ **Changez ces mots de passe immédiatement en production !**

---

## 🌐 Déploiement sur Render

### Étape 1 : Préparer GitHub

```bash
# Initialiser le repo (si pas déjà fait)
git init
git add .
git commit -m "Initial commit - AMANI NGUBA"
git branch -M main
git remote add origin https://github.com/VOTRE-USER/amani-nguba.git
git push -u origin main
```

### Étape 2 : Créer le service sur Render

1. Allez sur [render.com](https://render.com) et connectez-vous
2. Cliquez sur **"New +"** → **"Blueprint"**
3. Connectez votre repo GitHub `amani-nguba`
4. Render détecte automatiquement `render.yaml`
5. Cliquez sur **"Apply"**
6. Attendez ~5 minutes ⏱️
7. Votre app est en ligne sur `https://amani-nguba.onrender.com` 🎉

> Le `render.yaml` crée automatiquement :
> - Le service web (gratuit)
> - La base PostgreSQL (gratuite, expire après 90 jours)
> - Les variables d'environnement

### Étape 3 : Lancer les migrations en production

Une fois déployé, dans le **Shell** de votre service Render :

```bash
npm run migrate
npm run seed
```

---

## 📁 Structure du projet

```
amani-nguba/
├── server.js                # Point d'entrée
├── package.json
├── render.yaml              # Config Render
├── .env.example             # Variables d'environnement
│
├── config/
│   └── db.js                # Connexion PostgreSQL
│
├── routes/                  # Routes Express
│   ├── auth.js              # Login, register, profil
│   ├── dashboard.js         # Tableau de bord
│   ├── paroisses.js         # Organisation
│   ├── transactions.js      # Entrées/Sorties + exports
│   ├── budgets.js           # Budgets + rapports
│   ├── annonces.js          # Annonces
│   ├── analyses.js          # Statistiques
│   └── recompenses.js       # Fidèles de l'année
│
├── views/                   # Templates EJS
│   ├── partials/            # Header, navbar, footer, sidebar
│   ├── auth/                # Login, register, profile
│   ├── dashboard/
│   ├── paroisses/
│   ├── transactions/
│   ├── budgets/
│   ├── annonces/
│   ├── analyses/
│   ├── recompenses/
│   └── errors/              # 404, 500
│
├── public/
│   ├── css/style.css        # Thème pastoral (bleu + or)
│   └── js/app.js            # jQuery + AJAX
│
├── migrations/              # Scripts SQL
│   ├── 001_schema.sql       # Schéma complet
│   ├── run.js               # Exécution des migrations
│   └── seed.js              # Données initiales
│
└── scripts/
    └── setup.sh             # Installation automatique
```

---

## 🗄️ Schéma de base de données

### Tables principales

- **`paroisses`** — Arborescence complète (auto-référencée par `parent_id`)
- **`users`** — Utilisateurs avec 8 rôles
- **`transactions`** — Entrées et sorties
- **`categories_transactions`** — 22 catégories pré-configurées
- **`budgets`** — Budgets prévisionnels
- **`annonces`** — Annonces internes
- **`recompenses`** — Distinctions des fidèles
- **`session`** — Sessions PostgreSQL

### Vues SQL

- **`v_soldes_paroisses`** — Soldes par entité
- **`v_stats_mensuelles`** — Statistiques mensuelles

---

## 🎨 Thème visuel

Le thème est sobre et digne, à l'image de la tradition protestante :

- 🔵 **Bleu profond** `#1e3a5f` — Couleur principale (autorité, sérénité)
- 🟡 **Or sobre** `#c9a961` — Couleur secondaire (fidélité, lumière)
- ⚪ **Blanc cassé** `#f7fafc` — Fond (pureté, simplicité)

**Verset en bandeau** sur toutes les pages :
> *« Tout soit fait avec ordre et avec grâce »* — 1 Corinthiens 14:40

---

## 🔒 Sécurité

- ✅ Mots de passe hashés (bcrypt, 10 rounds)
- ✅ Sessions stockées en PostgreSQL (pas de mémoire)
- ✅ Cookies httpOnly en production
- ✅ Variables sensibles dans `.env` (jamais committé)
- ✅ Validation des entrées (express-validator)
- ✅ SQL préparé (protection injection)
- ✅ HTTPS automatique sur Render

---

## 🌍 Roadmap

- [ ] Application mobile (React Native)
- [ ] Notifications push pour annonces urgentes
- [ ] Reçus PDF automatiques pour les dîmes
- [ ] Système de messagerie interne
- [ ] Intégration SMS (pour les non-connectés)
- [ ] Multi-devises avec taux de change automatique
- [ ] Module de gestion des événements pastoraux

---

## 📜 Licence

MIT — Libre d'utilisation, modification et distribution.

---

## 🙏 Crédits

**AMANI NGUBA** est dédié à toutes les communautés CEPAC qui œuvrent pour une gestion transparente et fidèle des ressources confiées.

> *« Que la paix de Christ règne dans vos cœurs »* — Colossiens 3:15

---

**Fait avec ❤️ pour la gloire de Dieu**
